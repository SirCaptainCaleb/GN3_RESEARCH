# Longest-path support and exchange toolkit

## Statement

Reusable longest-path complement, support-graph, and exchange results for minimum-counterexample arguments.

## Body

Organizational Toolkit subnode for reusable longest-path support and exchange mathematics.

## Metadata

- ID: longestsupport01
- Kind: toolkit
- Version: 2
- Math version: 1
- Audit: unaudited
- Refutation: unrefuted
- Toolkit status: Promoted
