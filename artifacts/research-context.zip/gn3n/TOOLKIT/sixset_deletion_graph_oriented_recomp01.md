# Every six-set has adjacent good-deletion overlap or a canonically oriented matching-block exception

**Summary:** Every six-set has adjacent good-deletion overlap or a canonically oriented matching-block exception.

## Statement

Let H be any boundary tournament and let U be any six-vertex set. Put D={d in U:H[U-{d}] is Hamiltonian}, and join d,e in D in a graph J exactly when H[U-{d,e}] is Hamiltonian. Then |D|>=4 and delta(J)>=max{1,|D|-4}. Exactly one of the following structural alternatives holds. (1) J has adjacent edges de,df; then U-{d,e} and U-{d,f} are Hamiltonian four-sets meeting in three vertices, and their union U-{d} is a Hamiltonian five-set. (2) J has no adjacent edges; then |D|=4, J is a perfect matching, H[D] is a non-Hamiltonian matching-block K4, and writing U-D={a,b}, both D+{a} and D+{b} are non-Hamiltonian while every (D-{d})+{a} and (D-{d})+{b} is Hamiltonian. Moreover the fixed-pair Hamiltonian-extension graph on D relative to {a,b} is exactly J. Hence D=C_+ disjoint-union C_- with |C_+|=|C_-|=2, where C_+={y:(a,y,b) is tight} and C_-={z:(b,z,a) is tight}; the two matching edges are C_+ and C_-, and every cross pair y in C_+, z in C_- gives a non-Hamiltonian four-set {a,b,y,z} carrying the four tight hooks (a,y,b), (b,z,a), (y,a,z), (z,b,y). If H is a minimum counterexample, then in alternative (1) the two Hamiltonian four-sets and their Hamiltonian five-set union all have non-Hamiltonian path-cover-two complements.

## Body

Apply sixset_deletion_graph_strengthened01. It gives |D|>=4, the degree bound delta(J)>=max{1,|D|-4}, and the dichotomy between adjacent edges and the four-label perfect-matching residue. In the adjacent-edge case de,df, the two sets W=U-{d,e} and W'=U-{d,f} are Hamiltonian by definition of J; they meet in U-{d,e,f}, of order three, and their union is U-{d}, which is Hamiltonian because d lies in D. This proves alternative (1). If H is a minimum counterexample, W,W',U-{d} are proper Hamiltonian supports and mincex01 gives non-Hamiltonian path-cover-two complements. In the no-adjacent-edge case, sixset_deletion_graph_strengthened01 gives |D|=4, J a perfect matching, H[D] a non-Hamiltonian matching-block K4, and, writing U-D={a,b}, the two bad five-sets and all eight Hamiltonian four-replacements. Apply sixset_deletion_matching_oriented01 to this same residue. It shows that the fixed-pair extension graph on D relative to {a,b} is exactly the same perfect matching J, identifies its two edges with the two size-two orientation classes C_+,C_-, and supplies the complete four-hook rectangle on every cross pair. This is alternative (2).

## Metadata

- ID: sixset_deletion_graph_oriented_recomp01
- Kind: toolkit
- Version: 1
- Math version: 1
- Audit: unaudited
- Refutation: unrefuted
- Toolkit status: Limbo
