# Every prescribed pair in a six-set has a complete local transport menu

**Summary:** Every prescribed pair in a six-set has a complete local transport menu.

## Statement

Let H be any boundary tournament, let U be any six-vertex set, and fix distinct p,q in U. Put A=U-{p,q}. Then at least two distinct d in A satisfy that U-{d} is Hamiltonian. Moreover at least one of the following holds: (1) U is Hamiltonian; (2) at least one of U-{p}, U-{q} is Hamiltonian; (3) U is non-Hamiltonian, U-{p} and U-{q} are both non-Hamiltonian, and there exist distinct d,e,f in A such that U-{d,e} and U-{d,f} are Hamiltonian four-sets sharing three vertices, while U-{d} is Hamiltonian; (4) U is non-Hamiltonian, U-{p} and U-{q} are both non-Hamiltonian, A is a non-Hamiltonian matching-block four-set, and for every d in A both (A-{d}) union {p} and (A-{d}) union {q} are Hamiltonian. Equivalently, in the only no-overlap equality residue, the Hamiltonian-deletion set of U is exactly A, its Hamiltonian two-deletion graph is a perfect matching, and A is the retained non-Hamiltonian matching-block core. If H is a minimum counterexample, every proper Hamiltonian support appearing above has non-Hamiltonian path-cover-two complement.

## Body

Apply twofourhamdeletions01 to the disjoint two-set {p,q} and four-set A. It gives at least two d in A such that U-{d}=(A-{d}) union {p,q} is Hamiltonian. If U is Hamiltonian, (1) holds. If U-{p}=A union {q} or U-{q}=A union {p} is Hamiltonian, (2) holds. Hence assume U, U-{p}, and U-{q} are all non-Hamiltonian. Apply two_bad_five_extensions_all_opposite01 to A with exterior labels p,q. It gives U-{a} Hamiltonian for every a in A. Thus the Hamiltonian-deletion set D of U is exactly A. Apply sixset_deletion_graph_strengthened01. Its Hamiltonian two-deletion graph J on D either has adjacent edges de,df, in which case U-{d,e} and U-{d,f} are Hamiltonian four-sets sharing three vertices and their union U-{d} is Hamiltonian, giving (3); or J has no adjacent edges, in which case that theorem forces |D|=4, J a perfect matching, D=A a non-Hamiltonian matching-block K4, and all eight four-sets (A-{d}) union {p} and (A-{d}) union {q} Hamiltonian, giving (4). The local proof uses no ambient minimality. In a minimum counterexample, the final complement assertion follows from mincex01 for every proper Hamiltonian support listed.

## Metadata

- ID: sixset_prescribed_pair_menu01
- Kind: toolkit
- Version: 1
- Math version: 1
- Audit: unaudited
- Refutation: unrefuted
- Toolkit status: Limbo
